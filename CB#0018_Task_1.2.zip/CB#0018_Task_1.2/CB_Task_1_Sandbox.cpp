/*
*
* Team Id: 18
* Author List: Rachit Jain, Praneet Kapoor, Vaibhav Seth, Vikas Singh
* Filename: CB_Task_1_Sandbox.cpp
* Theme: Construct-O-Bot
* Functions: task1_2(), pilot(), sensor_status(), navigation_cases(), guidance_control(), program_counter(), node_handler(), blackout_phase_guidance_control()
* Global Variables: L, M, R, left_sensor, middle_sensor, right_sensor, PWM, code, counter, node[20]
* variables>
*
*/

#include "CB_Task_1_Sandbox.h"

int pilot();
int sensor_status();
int navigation_cases();
int guidance_control();
int program_counter();
int node_handler();
int blackout_phase_guidance_control();

int L, M, R, left_sensor, middle_sensor, right_sensor, PWM = 1, code = 2, counter = 0;
char node[20] = { 'L','R','R','L','R','F','L','R','L','L','F','R','L','F','R','E' }; //stores the command to be executed at each node that is encountered
/*
*
*LIST OF ALL POSSIBLE COMMANDS TO BE EXECUTED AT A GIVEN NODE
*L : Turn bot left by 90 degrees
*F : Move bot forward past the node
*R : Turn bot right by 90 degrees
*E : End of path
*NOTE : NODE NUMBER STARTS FROM 0, AND RANGE OF COUNTER DEPENDS UPON THE MAXIMUM NO. OF NODES IN THE PATH	
*
*/

/*
*
* Function Name: forward_wls
* Input: node
* Output: void
* Logic: Uses white line sensors to go forward by the number of nodes specified
* Example Call: forward_wls(2); //Goes forward by two nodes
*
*/
void forward_wls(unsigned char node)
{

}
/*
*
* Function Name: left_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn left until black line is encountered
* Example Call: left_turn_wls(); //Turns right until black line is encountered
*
*/
void left_turn_wls(void)
{

}

/*
*
* Function Name: right_turn_wls
* Input: void
* Output: void
* Logic: Uses white line sensors to turn right until black line is encountered
* Example Call: right_turn_wls(); //Turns right until black line is encountered
*/
void right_turn_wls(void)
{

}

/*
*
* Function Name: e_shape
* Input: void
* Output: void
* Logic: Use this function to make the robot trace a e shape path on the arena
* Example Call: e_shape();
*/

void e_shape(void)
{
	//enter assignment code here
}


/*
*
* Function Name: Task_1_1
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.1 logic
* Example Call: Task_1_1();
*/
void Task_1_1(void)
{
	pilot();	//Calls the pilot() function to start moving the bot on the required path
}

/*
*
* Function Name: pilot
* Input: none
* Output: returns 0 after the bot has reached the last node
* Logic: As the name suggests, this function "pilots" the bot in the following steps:
* 		1. call sensor_status() to update the value of white line sensors determine the position of the bot with respect to black line
* 		2. call navigation_cases() which on the basis if the value of the left, middle and right white line sensor assigns the case to 
*		   which the present position of bot belongs to  
*		3. call guidance_control() which on the basis of the cases positions the bot along the black line.
*		4. call program_counter() which on the basis of the number of nodes passed changes the speed of the bot using velocity() function.
*		5. return 0 if the program_counter() returns 16 which means that the last node has been reached.
* Example Call: pilot();
*
*/
int pilot()
{
	int ret; //stores the integer value returned by the program_counter(), RANGE 0 and 16
	while (1)	//and infinite loop keeps the pilot() running the bot unless the GOAL is reached
	{
		_delay_ms(1);	//a delay of 2 milliseconds prevents from calling the sensor_status() function at a high rate which can deviate the bot
		sensor_status();
		navigation_cases();
		guidance_control();
		ret = program_counter();		//value returned from program_counter() is stored in the variable ret
		if (ret == 16)					//if the value of ret is 16, it means that the bot has reached the GOAL
			break;						//if condition is true, break from the infinite while loop
	}
	stop();			//stop() any "dangling" motion left in the bot
	return 0;		//return 0
}

/*
*
* Function Name: sensor_status
* Input: none
* Output: returns 0 to the calling function
* Logic:  This function obtains the current value of the left, middle, and right white line sensors using 
*		  ADC_Conversion(). Before this, it stores the previous value of white line sensors: these values are used
*		  in correcting the tajectory of the bot if all the sensors are on a white surface.
* Example Call: sensor_status();
*
*/
int sensor_status()
{	//RANGE OF L, M, R, left_sensor, middle_sensor, and right_sensor : 0 - 255
	if (left_sensor >= 50 || middle_sensor >= 50 || right_sensor >= 50) //checks whether any of the three white line sensors
	{																	//have non zero value. This prevents L = M = R = 0 
																		//condition.
		L = left_sensor;	//store previous value of left_sensor in variable L
		M = middle_sensor;	//store previous value of middle_sensor in variable M
		R = right_sensor;	//store previous value of right_sensor in variable R
	}
	left_sensor = ADC_Conversion(1);	//stores current value of left white line sensor in left_sensor
	middle_sensor = ADC_Conversion(2);	//stores current value of middle white line sensor in middle_sensor
	right_sensor = ADC_Conversion(3);	//stores current value of right white line sensor in right_sensor
	return 0;	
}

/*
*
* Function Name: navigation_cases
* Input: none
* Output: returns 0
* Logic: Assigns codes to the current position of the bot. The code numbering is done in binary. Below is a list of all possible cases
* Code No. | left_sensor | middle_sensor | right_sensor
* 		0  |	  0		 |		 0		 |		0
*		1  |	  0		 | 		 0		 |		1
* 		2  |	  0		 |		 1		 |		0
*		3  |	  0		 | 		 1		 |		1
* 		4  |	  1 	 |		 0		 |		0
*		5  |	  1		 | 		 0		 |		1
* 		6  |	  1		 |		 1		 |		0
*		7  |	  1		 | 		 1		 |		1
* Example Call: navigation_cases();
*
*/
int navigation_cases()
{	//RANGE OF code: 0 - 7
	if (left_sensor < 50 && middle_sensor < 50 && right_sensor < 50)		//000 : all sensors on a white line
		code = 0;
	else if (left_sensor < 50 && middle_sensor < 50 && right_sensor >= 50)		//001
		code = 1;
	else if (left_sensor < 50 && middle_sensor >= 50 && right_sensor < 50)		//010 : sensors following a black line
		code = 2;
	else if (left_sensor < 50 && middle_sensor >= 50 && right_sensor >= 50) 		//011
		code = 3;
	else if (left_sensor >= 50 && middle_sensor < 50 && right_sensor < 50) 		//100
		code = 4;
	else if (left_sensor >= 50 && middle_sensor < 50 && right_sensor >= 50) 		//101 : an erronous condition when sensor is between a node and a line
		code = 5;
	else if (left_sensor >= 50 && middle_sensor >= 50 && right_sensor < 50)		//110
		code = 6;
	else if (left_sensor >= 50 && middle_sensor >= 50 && right_sensor >= 50)		//111 : sensors have detected a node
		code = 7;
	return 0;
}

/*
*
* Function Name: guidance_control
* Input: none
* Output: returns 0 after successfully position the middle white line sensor on the black line or after executing an opertion on a node
* Logic: Like the Apollo Guidance Computer, this function based on the codes assigned to the all possible positions of the bot (assuming
*		 only black line exists), positions the bot such that it is following the black line. In short, this function tries to position 
*		 the bot's middle sensor on a black line and the other two sensor on a white surface (condition of a line) or on a black surface
*		 (condition of a node). If a node is detected, the node_handler() function is called.
*		 Note that the threshhold value of line detection is taken to be 50, values above it imply a black line and below it a white surface.
* Example Call: guidance_control();
*
*/
int guidance_control()
{
	if (code == 0)		//code 0 : all sensors on a white surface
	{
		case000:		//label for re-execution of code 0 correction code below, in case the erro has not been resolved
		if (L >= 50 && R < 50)		//if previously left_sensor detected a black line and right sensor a white surface
		{
			while (left_sensor < 50 && middle_sensor < 50 && right_sensor < 50) 
			{
				left();			//turn the bot left till the code 0 is removed
				_delay_ms(1);
				stop();
				sensor_status(); 	//continuously update the value of sensors or the loop will keep running forever
			}
		}
		else if (R >= 50 && L < 50)		//if previously right_sensor detected a black line and left sensor a white sensor
		{
			while (left_sensor < 50 && middle_sensor < 50 && right_sensor < 50)
			{
				right();		//turn the bot right till the code 0 is removed
				_delay_ms(1);
				stop();
				sensor_status();	//continuously update the value of sensors or the loop will keep running forever
			}
		}
		else			//for all other previous values of white line sensors
		{				//in this error correction code the bot moves like a radar, sensing where a black line lies.
			int time = 0, limit = 80;		//limit of time is not so small that the error remains, neither too large that the bot 
	                                        //detects the line behind it or on side of a node
			while (time < limit)
			{
				left();
				_delay_ms(1);
				++time;
				stop();
				sensor_status();
				if (left_sensor >= 50 || middle_sensor >= 50 || right_sensor >= 50)
					return 0;
			}	
			time = 0;				//if no line is detected on the left side, then detect it it on the right side
			_delay_ms(10);
			while (time < 2 * limit)
			{
				right();
				_delay_ms(1);
				++time;
				stop();
				sensor_status();
				if (left_sensor >= 50 || middle_sensor >= 50 || right_sensor >= 50)
					return 0;
			}
		}
		sensor_status();
		if (left_sensor < 50 && middle_sensor < 50 && right_sensor < 50)		
			goto case000;			// if the error is not resolved then jump to label case000
		return 0;					//or return 0 to the calling function, pilot()
	}

	else if (code == 1)		//if right sensor is on a white line
	{
		while (middle_sensor < 50)
		{
			soft_right();			//move the bot right till middle sensor detects a line
			_delay_ms(1);
			stop();
			sensor_status();		//continuously update the sensor variables
		}
		return 0;
	}
	else if (code == 2)			//if the middle sensor is on a black line and all other sensors on a white surface then move forward
	{
		velocity(PWM, PWM);
		forward();
		_delay_ms(30);            
		stop();
		return 0;
	}
	else if (code == 3)			//if both middle sensor and right sensor register a black line
	{
		while (1)
		{
			soft_right();		//move right
			_delay_ms(1);
			stop();
			sensor_status();
			if (left_sensor >= 50)		//if left sensor is also registring a black line, then we have encountered a node
				goto node;
			else if (right_sensor == 0)  //if the right sensor is turned OFF then the bot is placed on a black line
				return 0;				
		}
	}
	else if (code == 4)			//if left sensor detects a black line
	{
		while (middle_sensor < 50)
		{
			soft_left();			//move the bot left till the middle sensor is place along the black line
			_delay_ms(1);
			stop();
			sensor_status();		//continuously update the sensor variables
		}
		return 0;
	}
	else if (code == 6)				//if both left sensor and middle sensor detect a black line
	{
		while (1)
		{
			soft_left();			//then move the bot left
			_delay_ms(1);
			stop();
			sensor_status();
			if (right_sensor >= 50)		//till either right_sensor also detects a black line which is the condition of a node
				goto node;
			else if (left_sensor == 0) //or till the left_sensor turns OFF which means that the middle sensor is now along the black line
				return 0;
		}
	}
	else if (code == 7)		//all three sensors are turned ON, i.e., a node has been detected
	{
	node:
		forward();			//move the bot forward for 20 milliseconds and check whether this has been a false alarm or not
		_delay_ms(20);
		stop();
		sensor_status();
		if (left_sensor >= 50 && middle_sensor >= 50 && right_sensor >= 50) //if this was not a false alarm then call node_handler()
		{
			node_handler();
			return 0;
		}
		else			//if this was a false alarm then return to pilot()
			return 0;
	}
}

/*
*
* Function Name: program_counter
* Input: none
* Output: returns 0
* Logic: This function assigns the PWM variable a value. The PWM variable is passed to velocity() in the format velocity(PWM, PWM) to 
*		 adjust the speed of the wheels. The value of PWM is decided on the basis of the complexity of the path: the first few nodes 
*		 are in closed turns to PWM is set to least value: 1. 
* Example Call: 
*
*/
int program_counter()
{								//RANGE OF PWM: 1 - 255
	if (counter == 0)
		PWM = 1;
	else if (counter == 3)
		PWM = 3;					
	else if (counter == 6)
		PWM = 5;					
	else if (counter == 11)
	{
		PWM = 1;
	}
	else if (counter == 12)
		PWM = 1;
	else if (counter == 15)			//case for last node, just before the GOAL
	{
		PWM = 5;                
		velocity(PWM, PWM);
		forward();
		_delay_ms(500);
		stop();
		return 16;					//return 16 if last node was detected 
	}
	return 0;			//else return 0
}

/*
*
* Function Name: node_handler
* Input: nonde
* Output: returns 0 to the calling function
* Logic:  This function, based on the global character array node[20] decides the direction in which the bot should move upon
* 		  encountering a node. The possible case are forward motion (stored as 'F' in the array), 90 degree left motion (stored as 
*		  'L' in the array), 90 degree right motion (stored as 'R' in the array) and end program after reaching GOAL (stored as
*		  'E' in the array). The exception is the conditional statement executed if counter is 11, which is the condtion when the 
* 		  bot has to follow a white line, and stop doing so if a black line has been detected.
* Example Call: node_handler();
*
*/
int node_handler()
{
	_delay_ms(500);			//Given so as to not produce any sudden jerks in the bot
	if (counter == 11)		//The exception case. It has been named by our team as the blackout phase
	{
		int t = 0, limit = 400;		//Maximum limit of time for which the bot should remain in the blackout phase, taking into considerations
									//possible corrections of errors.
		soft_right();
		_delay_ms(930);				//turn the bot 90 degrees after encountering node 11
		stop();
		velocity(5, 5);				//stop after rotation and set the velocity of both the wheels to 5
		while (t < limit)
		{
			forward();
			_delay_ms(100);			//move forward for 100 milliseconds if the bot is following a white line
			stop();
			blackout_phase_guidance_control();  //call the blackout_phase_guidance_control() to correct the trajector of the bot
			sensor_status();					//update sensor variables
			++t;				//increment time
			_delay_ms(80);			//delay for 80 milliseconds to prevent sudden jerks in the bots motion
			if (left_sensor < 50 && middle_sensor >= 50 && right_sensor < 50) //if a black line has been detected then break te while loop
				break;
		}
		velocity(1, 1);  //set the velocity of each of the wheels equal to 1, so that the tight turnes ahead are not missed
	}

	else if (node[counter] == 'F')
	{
		velocity(PWM, PWM);
		forward();						//If the node is makred F then move the bot forward for 300 milliseconds
		_delay_ms(300);
		stop();
	}
	else if (node[counter] == 'R')
	{
		velocity(PWM, PWM);
		soft_right();					//if the node is marked R then give the bot a 90 degree turn right
		_delay_ms(930);
		stop();
	}
	else if (node[counter] == 'L')
	{
		velocity(PWM, PWM);
		soft_left();					//if the node is marked L then give the bot a 90 degree turn left
		_delay_ms(930);
		stop();
	}
	else if (node[counter] == 'E')
		velocity(0, 0);					//if the node is marked E then put the wheels to rest.
	sensor_status();					//update sensor status
	++counter;							//increement the value of counter 
	return 0;
}

/*
*
* Function Name: blackout_phase_guidance_control
* Input: none
* Output: returns 0
* Logic: As the name suggests, this unction makes the bot follow the white line during blackout phase. And integral part of
*		 this control is to detect the blackline which lies ahead of the blackout phase. One can say that this code is a 
*		 minimalistic version of guidance control function.
* Example Call: <Example of how to call this function>
*
*/
int blackout_phase_guidance_control()
{
	if (left_sensor >= 50 && middle_sensor < 50 && right_sensor >= 50) //If the middle sensor i along a white line then...
	{
		forward();				//move forward for 10 milliseconds
		_delay_ms(10);
		stop();
		return 0;				//and then return 0 to the node_handler()
	}
	else
	{
		int t = 0, limit = 180;		//This case is similar to the code 000 correction subroutine, but with a greater limit
		while (t < limit)
		{
			right();			
			_delay_ms(1);			//move right for one millisecond
			stop();
			++t;
			sensor_status();		//update the value of sensor variables
			if (left_sensor >= 50 && middle_sensor < 50 && right_sensor >= 50) //if the bot is back on white line then return 0
				return 0;
			else if (left_sensor < 50 && middle_sensor >= 50 && right_sensor < 50) //if the sensors detect a black line then return 0
				return 0;
		}
		t = 0; //if turning right does not correct the trajectory in blackout phase then set t = 0 and turn the bot left
		while (t < 2 * limit)
		{
			left();
			_delay_ms(1);
			stop();
			++t;
			sensor_status();		//update the value of sensor variables
			if (left_sensor >= 50 && middle_sensor < 50 && right_sensor >= 50)	//if the bot is back on white line then return 0
				return 0;
			else if (left_sensor < 50 && middle_sensor >= 50 && right_sensor < 50) //if the sensors detect a black line then return 0
				return 0;
		}
	}
}


/*
*
* Function Name: Task_1_2
* Input: void
* Output: void
* Logic: Use this function to encapsulate your Task 1.2 logic
* Example Call: Task_1_2();
*/
void Task_1_2(void)
{
	//write your task 1.2 logic here
}
